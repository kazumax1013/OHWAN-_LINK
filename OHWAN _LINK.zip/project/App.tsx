import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View } from 'react-native';
import Timeline from './src/pages/Timeline';
import Groups from './src/pages/Groups';
import Messages from './src/pages/Messages';
import Events from './src/pages/Events';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <View style={styles.container}>
        <StatusBar style="auto" />
        <Stack.Navigator>
          <Stack.Screen name="Timeline" component={Timeline} />
          <Stack.Screen name="Groups" component={Groups} />
          <Stack.Screen name="Messages" component={Messages} />
          <Stack.Screen name="Events" component={Events} />
        </Stack.Navigator>
      </View>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});