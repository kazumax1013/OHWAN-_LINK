# Ohwan Link - Java起動ガイド

このドキュメントでは、JavaでOhwan Link Webアプリケーションを起動する方法を説明します。

## 前提条件

以下のソフトウェアがインストールされている必要があります：

- **Java 17以上**
- **Maven 3.6以上**
- **Node.js 16以上**
- **npm 8以上**

## プロジェクト構成

```
ohwan-link/
├── pom.xml                           # Maven設定ファイル
├── src/
│   └── main/
│       ├── java/
│       │   └── com/ohwan/link/
│       │       └── OhwanLinkApplication.java  # Spring Bootメインクラス
│       └── resources/
│           └── application.properties         # アプリケーション設定
├── dist/                             # ビルドされたフロントエンド
└── (その他のフロントエンドファイル)
```

## 起動方法

### 方法1: Mavenを使用（推奨）

#### ステップ1: フロントエンドをビルド

```bash
npm install
npm run build
```

#### ステップ2: Javaアプリケーションを起動

```bash
mvn spring-boot:run
```

これにより、以下の処理が自動実行されます：
1. npm installの実行
2. npm run buildの実行
3. ビルドファイル（dist/）をJARに組み込み
4. Spring Bootアプリケーションの起動

アプリケーションは `http://localhost:8080` で起動します。

### 方法2: JARファイルを作成して実行

#### ステップ1: JARファイルをビルド

```bash
mvn clean package
```

#### ステップ2: JARファイルを実行

```bash
java -jar target/ohwan-link-1.0.0.jar
```

## アプリケーションへのアクセス

起動後、ブラウザで以下のURLにアクセスしてください：

```
http://localhost:8080
```

## ポート変更

デフォルトではポート8080で起動します。別のポートを使用する場合は、以下のいずれかの方法で変更できます：

### application.propertiesを編集

```properties
server.port=9090
```

### 起動時にポートを指定

```bash
mvn spring-boot:run -Dspring-boot.run.arguments=--server.port=9090
```

または

```bash
java -jar target/ohwan-link-1.0.0.jar --server.port=9090
```

## トラブルシューティング

### ポートが既に使用されている

エラー: `Port 8080 is already in use`

**解決方法:**
1. 別のポートを使用する（上記「ポート変更」参照）
2. 使用中のプロセスを終了する

### npmコマンドが見つからない

エラー: `npm: command not found`

**解決方法:**
Node.jsとnpmをインストールしてください：
- https://nodejs.org/

### Javaバージョンエラー

エラー: `Unsupported class file major version`

**解決方法:**
Java 17以上をインストールしてください：
- https://adoptium.net/

### ビルドファイルが見つからない

エラー: ビルドファイルが見つからない

**解決方法:**
フロントエンドを手動でビルドしてください：
```bash
npm install
npm run build
```

## 環境変数

Supabaseの設定は `.env` ファイルで管理されています。必要に応じて以下の環境変数を設定してください：

- `VITE_SUPABASE_URL`: Supabaseプロジェクトの URL
- `VITE_SUPABASE_ANON_KEY`: Supabaseプロジェクトの匿名キー

## 本番環境へのデプロイ

本番環境にデプロイする場合は、以下の手順を実行してください：

1. 環境変数を本番用に設定
2. JARファイルをビルド: `mvn clean package -Pprod`
3. JARファイルをサーバーにデプロイ
4. Javaでアプリケーションを起動: `java -jar ohwan-link-1.0.0.jar`

## 停止方法

アプリケーションを停止するには、実行中のターミナルで `Ctrl+C` を押してください。

## サポート

問題が発生した場合は、以下を確認してください：
1. すべての前提条件が満たされているか
2. `.env` ファイルが正しく設定されているか
3. ログファイルでエラーメッセージを確認

---

**注意:** このアプリケーションはReact + Viteで構築されたSPA（Single Page Application）です。Spring BootはHTTPサーバーとして機能し、ビルドされた静的ファイルを配信します。
