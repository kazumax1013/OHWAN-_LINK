import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { groups } from '../data/mockData';
import { Users, Lock, Plus, Trash2, X } from 'lucide-react';

const Groups: React.FC = () => {
  const [localGroups, setLocalGroups] = useState(groups);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newGroup, setNewGroup] = useState({
    name: '',
    description: '',
    isPrivate: false
  });

  const handleCreateGroup = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newGroupData = {
      id: `group-${Date.now()}`,
      name: newGroup.name,
      description: newGroup.description,
      coverUrl: 'https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      createdAt: new Date().toISOString(),
      creatorId: '1', // In a real app, this would be the current user's ID
      members: ['1'], // In a real app, this would start with the creator
      isPrivate: newGroup.isPrivate
    };

    setLocalGroups(prev => [newGroupData, ...prev]);
    setShowCreateModal(false);
    setNewGroup({ name: '', description: '', isPrivate: false });
  };

  const handleDeleteGroup = (groupId: string, e: React.MouseEvent) => {
    e.preventDefault();
    setLocalGroups(prev => prev.filter(group => group.id !== groupId));
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">プロジェクト</h1>
        <button 
          onClick={() => setShowCreateModal(true)}
          className="flex items-center px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
        >
          <Plus className="h-4 w-4 mr-2" />
          プロジェクトを作成
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {localGroups.map(group => (
          <Link 
            key={group.id} 
            to={`/groups/${group.id}`}
            className="bg-white rounded-lg shadow overflow-hidden hover:shadow-md transition-shadow animate-fade-in group relative"
          >
            <div 
              className="h-36 bg-cover bg-center relative"
              style={{ backgroundImage: `url(${group.coverUrl})` }}
            >
              {group.isPrivate && (
                <div className="flex items-center justify-center h-8 w-8 bg-gray-800 bg-opacity-70 rounded-full ml-3 mt-3">
                  <Lock className="h-4 w-4 text-white" />
                </div>
              )}
              <button
                onClick={(e) => handleDeleteGroup(group.id, e)}
                className="absolute top-3 right-3 h-8 w-8 bg-red-500 bg-opacity-70 hover:bg-opacity-100 rounded-full flex items-center justify-center transition-all duration-200 opacity-0 group-hover:opacity-100"
              >
                <Trash2 className="h-4 w-4 text-white" />
              </button>
            </div>
            <div className="p-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">{group.name}</h3>
                <div className="flex items-center text-sm text-gray-500">
                  <Users className="h-4 w-4 mr-1" />
                  {group.members.length}
                </div>
              </div>
              <p className="text-gray-600 text-sm mt-1 line-clamp-2">{group.description}</p>
            </div>
          </Link>
        ))}
      </div>

      {/* Create Project Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="flex justify-between items-center px-6 py-4 border-b">
              <h2 className="text-xl font-semibold text-gray-900">新しいプロジェクト</h2>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <form onSubmit={handleCreateGroup} className="p-6">
              <div className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                    プロジェクト名
                  </label>
                  <input
                    type="text"
                    id="name"
                    value={newGroup.name}
                    onChange={(e) => setNewGroup(prev => ({ ...prev, name: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                    説明
                  </label>
                  <textarea
                    id="description"
                    value={newGroup.description}
                    onChange={(e) => setNewGroup(prev => ({ ...prev, description: e.target.value }))}
                    rows={3}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                    required
                  />
                </div>
                
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="isPrivate"
                    checked={newGroup.isPrivate}
                    onChange={(e) => setNewGroup(prev => ({ ...prev, isPrivate: e.target.checked }))}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                  />
                  <label htmlFor="isPrivate" className="ml-2 block text-sm text-gray-700">
                    プライベートプロジェクト
                  </label>
                </div>
              </div>
              
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 rounded-md"
                >
                  キャンセル
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 rounded-md"
                >
                  作成
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Groups;