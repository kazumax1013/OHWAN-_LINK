import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { formatDistanceToNow } from 'date-fns';
import { ja } from 'date-fns/locale';
import { Search, Users, MessageSquare, UserCheck } from 'lucide-react';
import CreateGroupChat from '../components/chat/CreateGroupChat';
import CreateMessageModal from '../components/chat/CreateMessageModal';

interface FollowingMember {
  id: string;
  name: string;
  position: string;
  department: string;
  avatarUrl: string;
  is_online: boolean;
}

interface ChatRoom {
  id: string;
  other_user_id: string;
  other_user_name: string;
  other_user_avatar: string;
  last_message: string;
  last_message_at: string;
  unread_count: number;
}

const Messages: React.FC = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [showNewMessage, setShowNewMessage] = useState(false);
  const [chatRooms, setChatRooms] = useState<ChatRoom[]>([]);
  const [followingMembers, setFollowingMembers] = useState<FollowingMember[]>([]);

  const fetchFollowingMembers = useCallback(async () => {
    if (!currentUser) return;

    try {
      const { data, error } = await supabase
        .from('follows')
        .select(`
          following_id,
          following:profiles!follows_following_id_fkey(
            id,
            name,
            position,
            department,
            avatar_url,
            is_online
          )
        `)
        .eq('follower_id', currentUser.id);

      if (error) {
        console.error('Failed to fetch following members:', error);
        throw error;
      }

      console.log('Fetched following data:', data);

      const members = (data || [])
        .filter(item => item.following)
        .map(item => {
          const profile = Array.isArray(item.following) ? item.following[0] : item.following;
          return {
            id: profile.id,
            name: profile.name,
            position: profile.position,
            department: profile.department,
            avatarUrl: profile.avatar_url,
            is_online: profile.is_online || false,
          };
        });

      console.log('Processed members:', members);
      setFollowingMembers(members);
    } catch (error) {
      console.error('Failed to fetch following members:', error);
      setFollowingMembers([]);
    }
  }, [currentUser]);

  const fetchChatRooms = useCallback(async () => {
    if (!currentUser) return;

    try {
      const { data, error } = await supabase
        .from('messages')
        .select(`
          id,
          sender_id,
          recipient_id,
          content,
          created_at,
          sender:profiles!messages_sender_id_fkey(id, name, avatar_url),
          recipient:profiles!messages_recipient_id_fkey(id, name, avatar_url)
        `)
        .or(`sender_id.eq.${currentUser.id},recipient_id.eq.${currentUser.id}`)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const roomsMap = new Map<string, ChatRoom>();

      (data || []).forEach((msg: any) => {
        const isCurrentUserSender = msg.sender_id === currentUser.id;
        const otherUserId = isCurrentUserSender ? msg.recipient_id : msg.sender_id;
        const otherUser = isCurrentUserSender
          ? (Array.isArray(msg.recipient) ? msg.recipient[0] : msg.recipient)
          : (Array.isArray(msg.sender) ? msg.sender[0] : msg.sender);

        if (!roomsMap.has(otherUserId) && otherUser) {
          roomsMap.set(otherUserId, {
            id: otherUserId,
            other_user_id: otherUserId,
            other_user_name: otherUser.name,
            other_user_avatar: otherUser.avatar_url,
            last_message: msg.content,
            last_message_at: msg.created_at,
            unread_count: 0
          });
        }
      });

      setChatRooms(Array.from(roomsMap.values()));
    } catch (error) {
      console.error('Failed to fetch chat rooms:', error);
      setChatRooms([]);
    }
  }, [currentUser]);

  useEffect(() => {
    fetchFollowingMembers();
    fetchChatRooms();
  }, [fetchFollowingMembers, fetchChatRooms]);

  // 通知からの遷移を処理
  useEffect(() => {
    const userId = searchParams.get('userId');
    const groupId = searchParams.get('groupId');

    if (userId) {
      // ダイレクトメッセージの場合
      navigate(`/messages/${userId}`, { replace: true });
    } else if (groupId) {
      // グループメッセージの場合
      navigate(`/groups/${groupId}`, { replace: true });
    }
  }, [searchParams, navigate]);

  const handleCreateGroup = (name: string, participants: string[]) => {
    console.log('Create group:', name, participants);
    setShowCreateGroup(false);
  };

  const handleCreateMessage = async (recipientId: string, messageContent: string) => {
    if (!currentUser) {
      console.error('No current user');
      alert('ログインしていません');
      return;
    }

    console.log('Sending message:', { recipientId, messageContent, senderId: currentUser.id });

    try {
      const { data, error } = await supabase
        .from('messages')
        .insert({
          sender_id: currentUser.id,
          recipient_id: recipientId,
          content: messageContent,
          is_read: false
        })
        .select();

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }

      console.log('Message sent successfully:', data);

      setShowNewMessage(false);
      await fetchChatRooms();
      navigate(`/messages/${recipientId}`);
    } catch (error) {
      console.error('Failed to send message:', error);
      alert(`チャットの送信に失敗しました: ${error instanceof Error ? error.message : '不明なエラー'}`);
    }
  };

  const handleStartChat = (memberId: string) => {
    navigate(`/messages/${memberId}`);
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <h1 className="text-2xl font-bold text-gray-900 whitespace-nowrap">チャット</h1>
        <div className="flex flex-wrap gap-3">
          <button
            className="flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors whitespace-nowrap"
            onClick={() => setShowCreateGroup(true)}
          >
            <Users className="h-4 w-4 mr-2" />
            新しいグループ
          </button>
          <button
            className="flex items-center px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors whitespace-nowrap"
            onClick={() => setShowNewMessage(true)}
          >
            <MessageSquare className="h-4 w-4 mr-2" />
            新しいチャット
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="p-4 border-b border-gray-200 bg-gray-50">
              <h2 className="text-sm font-semibold text-gray-900 flex items-center">
                <UserCheck className="h-4 w-4 mr-2" />
                フォロー中のメンバー
              </h2>
            </div>
            <div className="overflow-y-auto max-h-[600px]">
              {followingMembers.length === 0 ? (
                <div className="p-6 text-center">
                  <p className="text-sm text-gray-500">フォロー中のメンバーはいません</p>
                </div>
              ) : (
                <ul className="divide-y divide-gray-200">
                  {followingMembers.map(member => (
                    <li key={member.id}>
                      <button
                        onClick={() => handleStartChat(member.id)}
                        className="w-full text-left px-4 py-3 hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-center">
                          <div className="relative flex-shrink-0">
                            <img
                              src={member.avatarUrl}
                              alt={member.name}
                              className="h-10 w-10 rounded-full object-cover"
                            />
                            {member.is_online && (
                              <div className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 border-2 border-white rounded-full"></div>
                            )}
                          </div>
                          <div className="ml-3 flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">
                              {member.name}
                            </p>
                            <p className="text-xs text-gray-500 truncate">
                              {member.position}
                            </p>
                          </div>
                        </div>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>

        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-sm font-semibold text-gray-900 mb-3">チャット</h2>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-gray-50 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                  placeholder="チャットを検索..."
                />
              </div>
            </div>

            <div className="overflow-y-auto max-h-[600px]">
              {chatRooms.length === 0 ? (
                <div className="p-8 text-center">
                  <p className="text-gray-500">まだチャットはありません。会話を始めましょう！</p>
                </div>
              ) : (
                <ul className="divide-y divide-gray-200">
                  {chatRooms.map(room => (
                    <li key={room.id}>
                      <Link
                        to={`/messages/${room.other_user_id}`}
                        className="block hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-center px-4 py-4">
                          <div className="relative flex-shrink-0">
                            <img
                              src={room.other_user_avatar}
                              alt={room.other_user_name}
                              className="h-12 w-12 rounded-full object-cover"
                            />
                          </div>
                          <div className="ml-4 flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <p className="text-sm font-medium text-gray-900 truncate">
                                {room.other_user_name}
                              </p>
                              <p className="text-xs text-gray-500">
                                {formatDistanceToNow(new Date(room.last_message_at), { addSuffix: true, locale: ja })}
                              </p>
                            </div>
                            <div className="mt-1">
                              <p className="text-sm text-gray-500 truncate">
                                {room.last_message}
                              </p>
                            </div>
                          </div>
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      </div>

      {showCreateGroup && (
        <CreateGroupChat
          onClose={() => setShowCreateGroup(false)}
          onCreateGroup={handleCreateGroup}
        />
      )}

      {showNewMessage && (
        <CreateMessageModal
          onClose={() => setShowNewMessage(false)}
          onCreateMessage={handleCreateMessage}
        />
      )}
    </div>
  );
};

export default Messages;