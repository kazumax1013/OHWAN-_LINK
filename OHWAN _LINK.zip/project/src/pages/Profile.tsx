import React, { useState, useRef } from 'react';
import { useParams, Navigate, useNavigate } from 'react-router-dom';
import { getUserById } from '../data/mockData';
import { Building2, Phone, Calendar, Camera, Image as ImageIcon, Edit2, X, Check, LogOut, Trash2, Pencil } from 'lucide-react';
import PostCard from '../components/posts/PostCard';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import heic2any from 'heic2any';

const Profile: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { currentUser, logout, updateProfile } = useAuth();
  const navigate = useNavigate();
  const isOwnProfile = currentUser?.id === id || !id;
  const [profileData, setProfileData] = useState<any>(null);
  const [userPosts, setUserPosts] = useState<any[]>([]);
  const [recentReports, setRecentReports] = useState<any[]>([]);
  const [selectedReport, setSelectedReport] = useState<any>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [isFollowLoading, setIsFollowLoading] = useState(false);
  const [followerCount, setFollowerCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);

  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [coverPreview, setCoverPreview] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);

  const [editForm, setEditForm] = useState({
    name: '',
    position: '',
    office: '',
    department: '',
    phone: '',
    birthMonth: '',
    birthDay: '',
    motto: '',
    hobbies: '',
    introduction: '',
  });

  React.useEffect(() => {
    const fetchProfile = async () => {
      const userId = id || currentUser?.id;
      if (!userId) return;

      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (data) {
        setProfileData(data);

        let birthMonth = '';
        let birthDay = '';
        if (data.birthday) {
          const match = data.birthday.match(/(\d+)月(\d+)日/);
          if (match) {
            birthMonth = match[1];
            birthDay = match[2];
          }
        }

        setEditForm({
          name: data.name || '',
          position: data.position || '',
          office: data.office || '',
          department: data.department || '',
          phone: data.phone || '',
          birthMonth: birthMonth,
          birthDay: birthDay,
          motto: data.motto || '',
          hobbies: data.hobbies || '',
          introduction: data.introduction || '',
        });
      }
    };

    const fetchPosts = async () => {
      const userId = id || currentUser?.id;
      if (!userId) return;

      const { data: postsData } = await supabase
        .from('posts')
        .select(`
          *,
          profiles:user_id (
            id,
            name,
            avatar_url,
            department,
            position
          )
        `)
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (postsData) {
        const formattedPosts = postsData.map((post: any) => ({
          id: post.id,
          content: post.content,
          authorId: post.user_id,
          authorName: post.profiles?.name || '',
          authorAvatar: post.profiles?.avatar_url || '',
          authorDepartment: post.profiles?.department || '',
          authorPosition: post.profiles?.position || '',
          imageUrl: post.image_url,
          likes: post.likes_count || 0,
          comments: [],
          createdAt: post.created_at,
          updatedAt: post.updated_at,
          attachments: []
        }));
        setUserPosts(formattedPosts);
      }
    };

    const fetchReports = async () => {
      const userId = id || currentUser?.id;
      if (!userId) return;

      const { data: reportsData } = await supabase
        .from('daily_reports')
        .select('*')
        .eq('user_id', userId)
        .order('date', { ascending: false })
        .limit(2);

      if (reportsData) {
        setRecentReports(reportsData);
      }
    };

    const fetchFollowStatus = async () => {
      const userId = id || currentUser?.id;
      if (!userId || isOwnProfile) return;

      const { data } = await supabase
        .from('follows')
        .select('id')
        .eq('follower_id', currentUser?.id)
        .eq('following_id', userId)
        .maybeSingle();

      setIsFollowing(!!data);
    };

    const fetchFollowCounts = async () => {
      const userId = id || currentUser?.id;
      if (!userId) return;

      const { count: followers } = await supabase
        .from('follows')
        .select('*', { count: 'exact', head: true })
        .eq('following_id', userId);

      const { count: following } = await supabase
        .from('follows')
        .select('*', { count: 'exact', head: true })
        .eq('follower_id', userId);

      setFollowerCount(followers || 0);
      setFollowingCount(following || 0);
    };

    fetchProfile();
    fetchPosts();
    fetchReports();
    fetchFollowStatus();
    fetchFollowCounts();
  }, [id, currentUser, isOwnProfile]);

  const user = profileData ? {
    id: profileData.id,
    name: profileData.name,
    email: profileData.email,
    department: profileData.department,
    position: profileData.position,
    avatarUrl: profileData.avatar_url,
    skills: profileData.skills,
    interests: profileData.interests,
    joinedAt: profileData.joined_at,
    role: profileData.role
  } : (getUserById(id || '') || currentUser);


  if (!user) {
    return <Navigate to="/" replace />;
  }

  const convertHeicToJpeg = async (file: File): Promise<File> => {
    const fileExt = file.name.split('.').pop()?.toLowerCase();

    if (fileExt !== 'heic' && fileExt !== 'heif') {
      return file;
    }

    try {
      console.log('Converting HEIC to JPEG:', file.name);
      const convertedBlob = await heic2any({
        blob: file,
        toType: 'image/jpeg',
        quality: 0.9
      });

      const blob = Array.isArray(convertedBlob) ? convertedBlob[0] : convertedBlob;
      const newFileName = file.name.replace(/\.heic$/i, '.jpg').replace(/\.heif$/i, '.jpg');
      const convertedFile = new File([blob], newFileName, { type: 'image/jpeg' });

      console.log('HEIC conversion successful:', newFileName);
      return convertedFile;
    } catch (error) {
      console.error('Error converting HEIC to JPEG:', error);
      alert('HEIC画像の変換に失敗しました。別の形式の画像をお試しください。');
      throw error;
    }
  };

  const handleAvatarChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    let file = event.target.files?.[0];
    if (file && currentUser) {
      try {
        setIsUpdating(true);

        // Validate file type
        const fileExt = file.name.split('.').pop()?.toLowerCase();
        const isImage = file.type.startsWith('image/') || fileExt === 'heic' || fileExt === 'heif';

        if (!isImage) {
          alert('画像ファイルを選択してください');
          return;
        }

        // Convert HEIC to JPEG if needed
        file = await convertHeicToJpeg(file);

        // Validate file size (50MB limit)
        if (file.size > 50 * 1024 * 1024) {
          alert('ファイルサイズは50MB以下にしてください');
          return;
        }

        const finalFileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}.${finalFileExt}`;
        const filePath = `${currentUser.id}/avatars/${fileName}`;

        console.log('Uploading avatar to:', filePath);

        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('images')
          .upload(filePath, file, {
            cacheControl: '3600',
            upsert: false,
            contentType: file.type || 'application/octet-stream'
          });

        if (uploadError) {
          console.error('Upload error:', uploadError);
          alert(`アップロードエラー: ${uploadError.message}`);
          return;
        }

        console.log('Upload successful:', uploadData);

        const { data: { publicUrl } } = supabase.storage
          .from('images')
          .getPublicUrl(filePath);

        console.log('Public URL:', publicUrl);

        const success = await updateProfile({
          avatarUrl: publicUrl
        });

        if (success) {
          setAvatarPreview(publicUrl);
          // Refetch profile data instead of full page reload
          const { data } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', currentUser.id)
            .maybeSingle();

          if (data) {
            setProfileData(data);
          }
          alert('プロフィール画像を更新しました');
        } else {
          alert('プロフィールの更新に失敗しました');
        }
      } catch (error: any) {
        console.error('Failed to update avatar:', error);
        alert(`プロフィール画像の更新に失敗しました: ${error.message || '不明なエラー'}`);
      } finally {
        setIsUpdating(false);
      }
    }
  };

  const handleCoverChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    let file = event.target.files?.[0];
    if (file && currentUser) {
      try {
        setIsUpdating(true);

        // Validate file type
        const fileExt = file.name.split('.').pop()?.toLowerCase();
        const isImage = file.type.startsWith('image/') || fileExt === 'heic' || fileExt === 'heif';

        if (!isImage) {
          alert('画像ファイルを選択してください');
          return;
        }

        // Convert HEIC to JPEG if needed
        file = await convertHeicToJpeg(file);

        // Validate file size (50MB limit)
        if (file.size > 50 * 1024 * 1024) {
          alert('ファイルサイズは50MB以下にしてください');
          return;
        }

        const finalFileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}.${finalFileExt}`;
        const filePath = `${currentUser.id}/covers/${fileName}`;

        console.log('Uploading cover image to:', filePath);

        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('images')
          .upload(filePath, file, {
            cacheControl: '3600',
            upsert: false,
            contentType: file.type || 'application/octet-stream'
          });

        if (uploadError) {
          console.error('Upload error:', uploadError);
          alert(`アップロードエラー: ${uploadError.message}`);
          return;
        }

        console.log('Upload successful:', uploadData);

        const { data: { publicUrl } } = supabase.storage
          .from('images')
          .getPublicUrl(filePath);

        console.log('Public URL:', publicUrl);

        // Update profile with cover image URL
        const { error: updateError } = await supabase
          .from('profiles')
          .update({ cover_image_url: publicUrl })
          .eq('id', currentUser.id);

        if (updateError) {
          console.error('Failed to update profile:', updateError);
          alert('プロフィールの更新に失敗しました');
          return;
        }

        setCoverPreview(publicUrl);

        // Refetch profile data
        const { data } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', currentUser.id)
          .maybeSingle();

        if (data) {
          setProfileData(data);
        }

        alert('カバー画像を更新しました');
      } catch (error: any) {
        console.error('Failed to update cover:', error);
        alert(`カバー画像の更新に失敗しました: ${error.message || '不明なエラー'}`);
      } finally {
        setIsUpdating(false);
      }
    }
  };

  const handleBirthMonthChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setEditForm(prev => ({ ...prev, birthMonth: value }));
  };

  const handleBirthDayChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setEditForm(prev => ({ ...prev, birthDay: value }));
  };

  const getDaysInMonth = (month: string) => {
    if (!month) return 31;
    const daysMap: { [key: string]: number } = {
      '1': 31, '2': 29, '3': 31, '4': 30, '5': 31, '6': 30,
      '7': 31, '8': 31, '9': 30, '10': 31, '11': 30, '12': 31
    };
    return daysMap[month];
  };

  const formatBirthday = () => {
    if (editForm.birthMonth && editForm.birthDay) {
      return `${editForm.birthMonth}月${editForm.birthDay}日`;
    }
    return '未設定';
  };

  const handleSaveProfile = async () => {
    try {
      setIsUpdating(true);

      const birthday = (editForm.birthMonth && editForm.birthDay)
        ? `${editForm.birthMonth}月${editForm.birthDay}日`
        : null;

      const { error } = await supabase
        .from('profiles')
        .update({
          name: editForm.name || user.name,
          position: editForm.position || user.position,
          office: editForm.office || null,
          department: editForm.department || user.department,
          phone: editForm.phone || null,
          birthday: birthday,
          motto: editForm.motto || null,
          hobbies: editForm.hobbies || null,
          introduction: editForm.introduction || null
        })
        .eq('id', currentUser?.id);

      if (error) {
        console.error('Failed to save profile:', error);
        alert('プロフィールの更新に失敗しました');
        return;
      }

      await updateProfile({
        ...user,
        name: editForm.name || user.name,
        position: editForm.position || user.position,
        department: editForm.department || user.department
      });

      setIsEditing(false);
      window.location.reload();
    } catch (error) {
      console.error('Failed to save profile:', error);
      alert('プロフィールの更新に失敗しました');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleSignOut = () => {
    logout();
    navigate('/login');
  };

  const handleFollowToggle = async () => {
    if (!currentUser || isOwnProfile) return;

    const userId = id || currentUser?.id;
    if (!userId) return;

    setIsFollowLoading(true);
    try {
      if (isFollowing) {
        const { error } = await supabase
          .from('follows')
          .delete()
          .eq('follower_id', currentUser.id)
          .eq('following_id', userId);

        if (error) throw error;
        setIsFollowing(false);
        setFollowerCount(prev => prev - 1);
      } else {
        const { error } = await supabase
          .from('follows')
          .insert({
            follower_id: currentUser.id,
            following_id: userId
          });

        if (error) throw error;
        setIsFollowing(true);
        setFollowerCount(prev => prev + 1);
      }
    } catch (error) {
      console.error('Failed to toggle follow:', error);
      alert('フォロー操作に失敗しました');
    } finally {
      setIsFollowLoading(false);
    }
  };
  
  return (
    <div className="max-w-5xl mx-auto">
      <div className="bg-white rounded-lg shadow overflow-hidden mb-6 animate-fade-in">
        <div className="relative">
          <div
            className="h-60 bg-gradient-to-r from-primary-600 to-secondary-500 relative group"
            style={{
              backgroundImage: (coverPreview || profileData?.cover_image_url) ? `url(${coverPreview || profileData?.cover_image_url})` : undefined,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          >
            {isOwnProfile && (
              <button
                onClick={() => coverInputRef.current?.click()}
                disabled={isUpdating}
                className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity disabled:opacity-100"
              >
                {isUpdating ? (
                  <div className="flex flex-col items-center">
                    <svg className="animate-spin h-6 w-6 text-white mb-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span className="text-white text-xs">アップロード中...</span>
                  </div>
                ) : (
                  <div className="flex items-center text-white">
                    <ImageIcon className="h-5 w-5 mr-2" />
                    カバー画像を変更
                  </div>
                )}
              </button>
            )}
            <input
              ref={coverInputRef}
              type="file"
              accept="image/*,.heic,.heif"
              className="hidden"
              onChange={handleCoverChange}
            />
          </div>
          <div className="px-6 pb-6">
            <div className="flex flex-col sm:flex-row sm:items-end -mt-16 sm:-mt-20">
              <div className="relative group">
                <div className="w-32 h-32 sm:w-36 sm:h-36 rounded-full border-4 border-white overflow-hidden">
                  <img 
                    src={avatarPreview || user.avatarUrl}
                    alt={user.name}
                    className="h-full w-full object-cover"
                  />
                </div>
                {isOwnProfile && (
                  <button
                    onClick={() => avatarInputRef.current?.click()}
                    disabled={isUpdating}
                    className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity disabled:opacity-100"
                  >
                    {isUpdating ? (
                      <div className="flex flex-col items-center">
                        <svg className="animate-spin h-6 w-6 text-white mb-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <span className="text-white text-xs">アップロード中...</span>
                      </div>
                    ) : (
                      <Camera className="h-6 w-6 text-white" />
                    )}
                  </button>
                )}
                <input
                  ref={avatarInputRef}
                  type="file"
                  accept="image/*,.heic,.heif"
                  className="hidden"
                  onChange={handleAvatarChange}
                />
              </div>
              <div className="mt-4 sm:mt-0 sm:ml-6 flex-1">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    {isEditing ? (
                      <input
                        type="text"
                        value={editForm.name}
                        onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                        className="text-2xl font-bold text-gray-900 bg-gray-100 rounded px-2 py-1 w-full"
                        maxLength={30}
                        placeholder="名前"
                      />
                    ) : (
                      <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
                    )}
                    {isEditing ? (
                      <input
                        type="text"
                        value={editForm.position}
                        onChange={(e) => setEditForm(prev => ({ ...prev, position: e.target.value }))}
                        className="text-sm text-gray-600 bg-gray-100 rounded px-2 py-1 mt-1 w-full"
                        maxLength={30}
                        placeholder="役職"
                      />
                    ) : (
                      <p className="text-gray-600 text-sm">{user.position}</p>
                    )}
                  </div>
                  <div className="mt-4 sm:mt-0 flex space-x-2">
                    {isOwnProfile && (
                      <>
                        {isEditing ? (
                          <div className="flex space-x-2">
                            <button
                              onClick={() => setIsEditing(false)}
                              className="p-2 text-gray-500 hover:text-gray-700 rounded-full hover:bg-gray-100"
                              title="キャンセル"
                            >
                              <X className="h-5 w-5" />
                            </button>
                            <button
                              onClick={handleSaveProfile}
                              className="p-2 text-primary-600 hover:text-primary-700 rounded-full hover:bg-primary-50"
                              title="保存"
                              disabled={isUpdating}
                            >
                              <Check className="h-5 w-5" />
                            </button>
                          </div>
                        ) : (
                          <>
                            <button
                              onClick={() => setIsEditing(true)}
                              className="flex items-center px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
                            >
                              <Edit2 className="h-4 w-4 mr-2" />
                              プロフィールを編集
                            </button>
                            <button
                              onClick={handleSignOut}
                              className="flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
                            >
                              <LogOut className="h-4 w-4 mr-2" />
                              サインアウト
                            </button>
                          </>
                        )}
                      </>
                    )}
                    {!isOwnProfile && (
                      <button
                        onClick={handleFollowToggle}
                        disabled={isFollowLoading}
                        className={`px-4 py-2 rounded-md transition-colors ${
                          isFollowing
                            ? 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                            : 'bg-primary-600 text-white hover:bg-primary-700'
                        } disabled:opacity-50`}
                      >
                        {isFollowing ? 'フォロー中' : 'フォローする'}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-4 flex gap-4 text-sm">
              <div>
                <span className="font-semibold text-gray-900">{followerCount}</span>
                <span className="text-gray-600 ml-1">フォロワー</span>
              </div>
              <div>
                <span className="font-semibold text-gray-900">{followingCount}</span>
                <span className="text-gray-600 ml-1">フォロー中</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white rounded-lg shadow p-5 animate-fade-in">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">基本情報</h3>
            <div className="space-y-3">
              <div className="flex">
                <Building2 className="h-5 w-5 text-gray-500 mr-3 flex-shrink-0" />
                <div className="w-full">
                  {isEditing ? (
                    <select
                      value={editForm.office}
                      onChange={(e) => setEditForm(prev => ({ ...prev, office: e.target.value }))}
                      className="w-full text-sm bg-gray-100 rounded px-2 py-1"
                    >
                      <option value="">所属を選択</option>
                      <option value="大阪本社">大阪本社</option>
                      <option value="東京営業所">東京営業所</option>
                    </select>
                  ) : (
                    <p className="text-sm text-gray-900">{editForm.office || '未設定'}</p>
                  )}
                </div>
              </div>
              <div className="flex">
                <Building2 className="h-5 w-5 text-gray-500 mr-3 flex-shrink-0" />
                <div className="w-full">
                  {isEditing ? (
                    <select
                      value={editForm.department}
                      onChange={(e) => setEditForm(prev => ({ ...prev, department: e.target.value }))}
                      className="w-full text-sm bg-gray-100 rounded px-2 py-1"
                    >
                      <option value="">部署を選択</option>
                      <option value="役員">役員</option>
                      <option value="営業">営業</option>
                      <option value="製作">製作</option>
                      <option value="オペレーター">オペレーター</option>
                      <option value="総務・経理">総務・経理</option>
                    </select>
                  ) : (
                    <p className="text-sm text-gray-900">{user.department}</p>
                  )}
                </div>
              </div>
              <div className="flex">
                <Phone className="h-5 w-5 text-gray-500 mr-3 flex-shrink-0" />
                <div>
                  {isEditing ? (
                    <input
                      type="tel"
                      value={editForm.phone}
                      onChange={(e) => setEditForm(prev => ({ ...prev, phone: e.target.value }))}
                      className="w-full text-sm bg-gray-100 rounded px-2 py-1"
                      placeholder="会社携帯"
                      maxLength={30}
                    />
                  ) : (
                    <p className="text-sm text-gray-900">{editForm.phone || '未設定'}</p>
                  )}
                </div>
              </div>
              <div className="flex">
                <Calendar className="h-5 w-5 text-gray-500 mr-3 flex-shrink-0" />
                <div>
                  {isEditing ? (
                    <div className="flex space-x-2">
                      <select
                        value={editForm.birthMonth}
                        onChange={handleBirthMonthChange}
                        className="w-24 text-sm bg-gray-100 rounded px-2 py-1"
                      >
                        <option value="">月</option>
                        {Array.from({ length: 12 }, (_, i) => i + 1).map(month => (
                          <option key={month} value={month}>{month}月</option>
                        ))}
                      </select>
                      <select
                        value={editForm.birthDay}
                        onChange={handleBirthDayChange}
                        className="w-24 text-sm bg-gray-100 rounded px-2 py-1"
                      >
                        <option value="">日</option>
                        {Array.from({ length: getDaysInMonth(editForm.birthMonth) }, (_, i) => i + 1).map(day => (
                          <option key={day} value={day}>{day}日</option>
                        ))}
                      </select>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-900">誕生日: {formatBirthday()}</p>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-5 animate-fade-in">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">プロフィール</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  座右の銘
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    value={editForm.motto}
                    onChange={(e) => setEditForm(prev => ({ ...prev, motto: e.target.value }))}
                    className="w-full text-sm bg-gray-100 rounded px-2 py-1"
                    placeholder="座右の銘を入力"
                    maxLength={50}
                  />
                ) : (
                  <p className="text-sm text-gray-900">{editForm.motto || '未設定'}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  趣味
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    value={editForm.hobbies}
                    onChange={(e) => setEditForm(prev => ({ ...prev, hobbies: e.target.value }))}
                    className="w-full text-sm bg-gray-100 rounded px-2 py-1"
                    placeholder="趣味を入力"
                    maxLength={100}
                  />
                ) : (
                  <p className="text-sm text-gray-900">{editForm.hobbies || '未設定'}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  自己紹介
                </label>
                {isEditing ? (
                  <textarea
                    value={editForm.introduction}
                    onChange={(e) => setEditForm(prev => ({ ...prev, introduction: e.target.value }))}
                    className="w-full text-sm bg-gray-100 rounded px-2 py-1"
                    placeholder="自己紹介を入力"
                    rows={4}
                    maxLength={400}
                  />
                ) : (
                  <p className="text-sm text-gray-900 whitespace-pre-wrap">{editForm.introduction || '未設定'}</p>
                )}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-5 animate-fade-in">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">直近の日報</h3>
              <a href="/daily-reports" className="text-sm text-primary-600 hover:text-primary-700">
                すべて表示
              </a>
            </div>
            <div className="space-y-4">
              {recentReports.length === 0 ? (
                <p className="text-sm text-gray-500 text-center py-4">日報がありません</p>
              ) : (
                recentReports.map((report: any) => (
                  <div
                    key={report.id}
                    className="border border-gray-200 rounded-lg p-4 cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => setSelectedReport(report)}
                  >
                    <div className="flex items-center text-sm text-gray-500 mb-3">
                      <Calendar className="h-4 w-4 mr-2" />
                      {new Date(report.date).toLocaleDateString('ja-JP')}
                    </div>

                    <div className="space-y-2">
                      {report.site_work && report.site_work.length > 0 && (
                        <div className="text-sm">
                          <span className="font-medium text-gray-700">現場:</span>
                          <span className="text-gray-900 ml-2">{report.site_work[0]}</span>
                          {report.site_work.length > 1 && (
                            <span className="text-gray-500 ml-1">他{report.site_work.length - 1}件</span>
                          )}
                        </div>
                      )}

                      {report.delivery && report.delivery.length > 0 && (
                        <div className="text-sm">
                          <span className="font-medium text-gray-700">納品:</span>
                          <span className="text-gray-900 ml-2">{report.delivery[0]}</span>
                          {report.delivery.length > 1 && (
                            <span className="text-gray-500 ml-1">他{report.delivery.length - 1}件</span>
                          )}
                        </div>
                      )}

                      {report.meeting && report.meeting.length > 0 && (
                        <div className="text-sm">
                          <span className="font-medium text-gray-700">打合:</span>
                          <span className="text-gray-900 ml-2">{report.meeting[0]}</span>
                          {report.meeting.length > 1 && (
                            <span className="text-gray-500 ml-1">他{report.meeting.length - 1}件</span>
                          )}
                        </div>
                      )}

                      {report.production && report.production.length > 0 && (
                        <div className="text-sm">
                          <span className="font-medium text-gray-700">制作:</span>
                          <span className="text-gray-900 ml-2">{report.production[0]}</span>
                          {report.production.length > 1 && (
                            <span className="text-gray-500 ml-1">他{report.production.length - 1}件</span>
                          )}
                        </div>
                      )}

                      {report.estimate && report.estimate.length > 0 && (
                        <div className="text-sm">
                          <span className="font-medium text-gray-700">見積:</span>
                          <span className="text-gray-900 ml-2">{report.estimate[0]}</span>
                          {report.estimate.length > 1 && (
                            <span className="text-gray-500 ml-1">他{report.estimate.length - 1}件</span>
                          )}
                        </div>
                      )}

                      {report.today_comment && (
                        <div className="text-sm text-gray-600 italic border-t border-gray-100 pt-2 mt-2">
                          "{report.today_comment.length > 50 ? report.today_comment.substring(0, 50) + '...' : report.today_comment}"
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-2 space-y-6">
          {userPosts.length > 0 ? (
            userPosts.map(post => (
              <PostCard key={post.id} post={post} />
            ))
          ) : (
            <div className="bg-white rounded-lg shadow p-8 text-center">
              <p className="text-gray-500">投稿はありません</p>
            </div>
          )}
        </div>
      </div>

      {selectedReport && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedReport(null)}
        >
          <div
            className="bg-white rounded-lg max-w-2xl w-full max-h-[80vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900">日報詳細</h2>
              <div className="flex items-center gap-2">
                {isOwnProfile && (
                  <>
                    <button
                      onClick={() => navigate('/daily-reports')}
                      className="text-blue-600 hover:text-blue-700 transition-colors p-2 hover:bg-blue-50 rounded"
                      title="編集"
                    >
                      <Pencil className="h-5 w-5" />
                    </button>
                    <button
                      onClick={async () => {
                        if (window.confirm('この日報を削除してもよろしいですか？')) {
                          setIsDeleting(true);
                          try {
                            const { error } = await supabase
                              .from('daily_reports')
                              .delete()
                              .eq('id', selectedReport.id);

                            if (error) throw error;

                            setRecentReports(prev => prev.filter(r => r.id !== selectedReport.id));
                            setSelectedReport(null);
                          } catch (error) {
                            console.error('Error deleting report:', error);
                            alert('日報の削除に失敗しました');
                          } finally {
                            setIsDeleting(false);
                          }
                        }
                      }}
                      disabled={isDeleting}
                      className="text-red-600 hover:text-red-700 transition-colors p-2 hover:bg-red-50 rounded disabled:opacity-50"
                      title="削除"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </>
                )}
                <button
                  onClick={() => setSelectedReport(null)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              <div className="flex items-center justify-center pb-4 border-b border-gray-200">
                <div className="flex items-center text-gray-600">
                  <Calendar className="h-5 w-5 mr-2" />
                  <span className="font-medium">
                    {new Date(selectedReport.date).toLocaleDateString('ja-JP', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      weekday: 'long'
                    })}
                  </span>
                </div>
              </div>

              {selectedReport.site_work && selectedReport.site_work.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 mb-2">今日の現場</h3>
                  <ul className="space-y-2">
                    {selectedReport.site_work.map((item: string, idx: number) => (
                      <li key={idx} className="flex items-start">
                        <span className="text-blue-600 mr-2">•</span>
                        <span className="text-gray-900">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {selectedReport.delivery && selectedReport.delivery.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 mb-2">今日の納品</h3>
                  <ul className="space-y-2">
                    {selectedReport.delivery.map((item: string, idx: number) => (
                      <li key={idx} className="flex items-start">
                        <span className="text-green-600 mr-2">•</span>
                        <span className="text-gray-900">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {selectedReport.meeting && selectedReport.meeting.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 mb-2">今日の打ち合わせ</h3>
                  <ul className="space-y-2">
                    {selectedReport.meeting.map((item: string, idx: number) => (
                      <li key={idx} className="flex items-start">
                        <span className="text-pink-600 mr-2">•</span>
                        <span className="text-gray-900">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {selectedReport.production && selectedReport.production.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 mb-2">今日の制作作業</h3>
                  <ul className="space-y-2">
                    {selectedReport.production.map((item: string, idx: number) => (
                      <li key={idx} className="flex items-start">
                        <span className="text-orange-600 mr-2">•</span>
                        <span className="text-gray-900">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {selectedReport.estimate && selectedReport.estimate.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 mb-2">今日の見積書</h3>
                  <ul className="space-y-2">
                    {selectedReport.estimate.map((item: string, idx: number) => (
                      <li key={idx} className="flex items-start">
                        <span className="text-teal-600 mr-2">•</span>
                        <span className="text-gray-900">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {selectedReport.tomorrow_plan && selectedReport.tomorrow_plan.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 mb-2">明日の予定</h3>
                  <ul className="space-y-2">
                    {selectedReport.tomorrow_plan.map((item: string, idx: number) => (
                      <li key={idx} className="flex items-start">
                        <span className="text-emerald-600 mr-2">•</span>
                        <span className="text-gray-900">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {selectedReport.future_plan && selectedReport.future_plan.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 mb-2">先の予定</h3>
                  <ul className="space-y-2">
                    {selectedReport.future_plan.map((item: string, idx: number) => (
                      <li key={idx} className="flex items-start">
                        <span className="text-cyan-600 mr-2">•</span>
                        <span className="text-gray-900">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {selectedReport.today_comment && (
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 mb-2">今日の一言</h3>
                  <p className="text-gray-900 whitespace-pre-wrap">{selectedReport.today_comment}</p>
                </div>
              )}

              <div className="text-xs text-gray-500 pt-4 border-t border-gray-200">
                投稿日時: {new Date(selectedReport.created_at).toLocaleString('ja-JP')}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Profile;