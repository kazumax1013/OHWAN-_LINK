import { createClient } from 'npm:@supabase/supabase-js@2.80.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const formData = await req.formData();
    const file = formData.get('file') as File;
    const filePath = formData.get('filePath') as string;
    const contentType = formData.get('contentType') as string;

    if (!file || !filePath) {
      return new Response(
        JSON.stringify({ error: 'Missing file or filePath' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const CHUNK_SIZE = 40 * 1024 * 1024;
    const fileSize = file.size;
    const numChunks = Math.ceil(fileSize / CHUNK_SIZE);

    console.log(`Uploading file: ${file.name}, size: ${fileSize}, chunks: ${numChunks}`);

    if (numChunks === 1) {
      const { data, error } = await supabase.storage
        .from('images')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false,
          contentType: contentType || file.type,
        });

      if (error) {
        console.error('Upload error:', error);
        return new Response(
          JSON.stringify({ error: error.message }),
          {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      return new Response(
        JSON.stringify({ success: true, path: data.path }),
        {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const fileBuffer = await file.arrayBuffer();
    const uploadId = crypto.randomUUID();
    const tempChunkPaths: string[] = [];

    for (let i = 0; i < numChunks; i++) {
      const start = i * CHUNK_SIZE;
      const end = Math.min(start + CHUNK_SIZE, fileSize);
      const chunk = fileBuffer.slice(start, end);
      const chunkPath = `${filePath}.chunk.${uploadId}.${i}`;

      const { error: chunkError } = await supabase.storage
        .from('images')
        .upload(chunkPath, chunk, {
          cacheControl: '3600',
          upsert: false,
          contentType: 'application/octet-stream',
        });

      if (chunkError) {
        for (const path of tempChunkPaths) {
          await supabase.storage.from('images').remove([path]);
        }
        console.error('Chunk upload error:', chunkError);
        return new Response(
          JSON.stringify({ error: `Chunk ${i} upload failed: ${chunkError.message}` }),
          {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      tempChunkPaths.push(chunkPath);
      console.log(`Uploaded chunk ${i + 1}/${numChunks}`);
    }

    const combinedBuffer = new Uint8Array(fileSize);
    let offset = 0;

    for (let i = 0; i < numChunks; i++) {
      const chunkPath = tempChunkPaths[i];
      const { data: chunkData, error: downloadError } = await supabase.storage
        .from('images')
        .download(chunkPath);

      if (downloadError || !chunkData) {
        for (const path of tempChunkPaths) {
          await supabase.storage.from('images').remove([path]);
        }
        console.error('Chunk download error:', downloadError);
        return new Response(
          JSON.stringify({ error: `Chunk ${i} download failed` }),
          {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      const chunkBuffer = new Uint8Array(await chunkData.arrayBuffer());
      combinedBuffer.set(chunkBuffer, offset);
      offset += chunkBuffer.length;
    }

    const { data: finalData, error: finalError } = await supabase.storage
      .from('images')
      .upload(filePath, combinedBuffer, {
        cacheControl: '3600',
        upsert: false,
        contentType: contentType || file.type,
      });

    for (const path of tempChunkPaths) {
      await supabase.storage.from('images').remove([path]);
    }

    if (finalError) {
      console.error('Final upload error:', finalError);
      return new Response(
        JSON.stringify({ error: finalError.message }),
        {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    console.log('Upload completed successfully');

    return new Response(
      JSON.stringify({ success: true, path: finalData.path }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Unexpected error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});